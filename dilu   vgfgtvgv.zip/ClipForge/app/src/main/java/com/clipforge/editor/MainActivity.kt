package com.clipforge.editor

import android.content.ContentValues
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Spannable
import android.text.SpannableString
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.TextOverlay
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.clipforge.editor.databinding.ActivityMainBinding
import com.google.android.material.slider.RangeSlider
import com.google.android.material.slider.Slider
import com.google.common.collect.ImmutableList
import java.io.File

@UnstableApi
class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private var player: ExoPlayer? = null
    private var transformer: Transformer? = null
    private val handler = Handler(Looper.getMainLooper())

    private var videoUri: Uri? = null
    private var musicUri: Uri? = null
    private var fullDurationMs = 0L
    private var exporting = false

    private val filters = listOf("Original", "B&W", "Invert", "Vintage", "Warm", "Cool", "Vivid", "Fade")
    private val textPositions = listOf("Upar", "Beech mein", "Neeche")
    private val qualities = listOf("720p", "1080p", "Original size")

    private val pickVideo =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) loadVideo(uri)
        }

    private val pickMusic =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                musicUri = uri
                b.btnPickMusic.text = "Music laga hai (badalne ke liye dabao)"
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        player = ExoPlayer.Builder(this).build()
        b.playerView.player = player

        b.spFilter.adapter = adapterOf(filters)
        b.spTextPos.adapter = adapterOf(textPositions)
        b.spQuality.adapter = adapterOf(qualities)

        b.btnPickVideo.setOnClickListener { pickVideo.launch("video/*") }
        b.btnPickMusic.setOnClickListener { pickMusic.launch("audio/*") }
        b.btnApplyText.setOnClickListener { refreshEffects() }
        b.btnExport.setOnClickListener { startExport() }

        b.spFilter.onPick { refreshEffects() }
        b.spTextPos.onPick { refreshEffects() }

        b.rsTrim.addOnChangeListener { slider, _, _ -> updateTrimLabel(slider.values) }
        b.rsTrim.addOnSliderTouchListener(object : RangeSlider.OnSliderTouchListener {
            override fun onStartTrackingTouch(slider: RangeSlider) {}
            override fun onStopTrackingTouch(slider: RangeSlider) {
                refreshPreview()
            }
        })

        listOf(b.slBrightness, b.slContrast, b.slSaturation, b.slTextSize).forEach { s ->
            s.addOnSliderTouchListener(object : Slider.OnSliderTouchListener {
                override fun onStartTrackingTouch(slider: Slider) {}
                override fun onStopTrackingTouch(slider: Slider) {
                    refreshEffects()
                }
            })
        }

        b.slSpeed.addOnChangeListener { _, value, _ ->
            b.tvSpeed.text = "Speed: ${value}x"
        }
        b.slSpeed.addOnSliderTouchListener(object : Slider.OnSliderTouchListener {
            override fun onStartTrackingTouch(slider: Slider) {}
            override fun onStopTrackingTouch(slider: Slider) {
                refreshEffects()
            }
        })
    }

    // ---------- helpers ----------

    private fun adapterOf(items: List<String>) =
        ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)

    private fun Spinner.onPick(f: () -> Unit) {
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = f()
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun updateTrimLabel(values: List<Float>) {
        if (values.size >= 2) {
            b.tvTrim.text = String.format("%.1fs - %.1fs", values[0], values[1])
        }
    }

    private fun trimStartMs(): Long = (b.rsTrim.values[0] * 1000).toLong()
    private fun trimEndMs(): Long = (b.rsTrim.values[1] * 1000).toLong()
    private fun speed(): Float = b.slSpeed.value

    // ---------- loading & preview ----------

    private fun loadVideo(uri: Uri) {
        videoUri = uri
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, uri)
            fullDurationMs = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            fullDurationMs = 0L
        } finally {
            retriever.release()
        }
        if (fullDurationMs <= 0L) {
            toast("Video padh nahi paaya, doosri file try karo")
            videoUri = null
            return
        }
        val secs = fullDurationMs / 1000f
        b.rsTrim.isEnabled = true
        b.rsTrim.valueFrom = 0f
        b.rsTrim.valueTo = secs
        b.rsTrim.values = listOf(0f, secs)
        updateTrimLabel(b.rsTrim.values)
        b.tvStatus.text = "Video load ho gayi"
        refreshPreview()
    }

    /** Trim change hone par: media item dobara set karo + effects lagao. */
    private fun refreshPreview() {
        val uri = videoUri ?: return
        val p = player ?: return
        val item = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(clip(trimStartMs(), trimEndMs()))
            .build()
        p.setMediaItem(item)
        p.prepare()
        refreshEffects()
        p.playWhenReady = true
    }

    /** Filter/text/speed change hone par sirf effects badlo. */
    private fun refreshEffects() {
        if (videoUri == null) return
        val p = player ?: return
        p.setVideoEffects(buildVideoEffects(forExport = false))
        p.playbackParameters = PlaybackParameters(speed())
    }

    private fun clip(startMs: Long, endMs: Long): MediaItem.ClippingConfiguration =
        MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(startMs)
            .setEndPositionMs(endMs)
            .build()

    // ---------- effects ----------

    private fun buildVideoEffects(forExport: Boolean): List<Effect> {
        val list = mutableListOf<Effect>()

        if (forExport && speed() != 1f) list.add(SpeedChangeEffect(speed()))

        when (b.spFilter.selectedItemPosition) {
            1 -> list.add(RgbFilter.createGrayscaleFilter())
            2 -> list.add(RgbFilter.createInvertedFilter())
            3 -> {
                list.add(
                    RgbAdjustment.Builder()
                        .setRedScale(1.1f).setGreenScale(0.95f).setBlueScale(0.8f)
                        .build()
                )
                list.add(Contrast(-0.1f))
            }
            4 -> list.add(
                RgbAdjustment.Builder().setRedScale(1.15f).setBlueScale(0.88f).build()
            )
            5 -> list.add(
                RgbAdjustment.Builder().setRedScale(0.88f).setBlueScale(1.15f).build()
            )
            6 -> {
                list.add(HslAdjustment.Builder().adjustSaturation(40f).build())
                list.add(Contrast(0.15f))
            }
            7 -> {
                list.add(Contrast(-0.25f))
                list.add(Brightness(0.08f))
            }
        }

        val br = b.slBrightness.value
        val ct = b.slContrast.value
        val sat = b.slSaturation.value
        if (br != 0f) list.add(Brightness(br))
        if (ct != 0f) list.add(Contrast(ct))
        if (sat != 0f) list.add(HslAdjustment.Builder().adjustSaturation(sat).build())

        textEffect()?.let { list.add(it) }

        if (forExport) {
            when (b.spQuality.selectedItemPosition) {
                0 -> list.add(Presentation.createForHeight(720))
                1 -> list.add(Presentation.createForHeight(1080))
            }
        }
        return list
    }

    private fun textEffect(): OverlayEffect? {
        val t = b.etText.text?.toString()?.trim().orEmpty()
        if (t.isEmpty()) return null

        val span = SpannableString(t)
        span.setSpan(ForegroundColorSpan(Color.WHITE), 0, t.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        span.setSpan(AbsoluteSizeSpan(b.slTextSize.value.toInt()), 0, t.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        span.setSpan(StyleSpan(Typeface.BOLD), 0, t.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)

        val y = when (b.spTextPos.selectedItemPosition) {
            0 -> 0.8f
            1 -> 0f
            else -> -0.8f
        }
        val settings = OverlaySettings.Builder()
            .setBackgroundFrameAnchor(0f, y)
            .build()
        return OverlayEffect(
            ImmutableList.of(TextOverlay.createStaticTextOverlay(span, settings))
        )
    }

    // ---------- export ----------

    private fun startExport() {
        val uri = videoUri
        if (uri == null) {
            toast("Pehle video chuno")
            return
        }
        if (exporting) return

        val startMs = trimStartMs()
        val endMs = trimEndMs()
        if (endMs - startMs < 500) {
            toast("Trim bahut chhota hai")
            return
        }
        val sp = speed()

        val audioProcessors = mutableListOf<AudioProcessor>()
        if (sp != 1f) {
            val sonic = SonicAudioProcessor()
            sonic.setSpeed(sp)
            audioProcessors.add(sonic)
        }

        val videoItem = EditedMediaItem.Builder(
            MediaItem.Builder().setUri(uri).setClippingConfiguration(clip(startMs, endMs)).build()
        )
            .setRemoveAudio(b.cbMute.isChecked)
            .setEffects(Effects(audioProcessors, buildVideoEffects(forExport = true)))
            .build()

        val sequences = mutableListOf(EditedMediaItemSequence(listOf(videoItem)))

        musicUri?.let { m ->
            val outDurMs = ((endMs - startMs) / sp).toLong()
            val musicItem = EditedMediaItem.Builder(
                MediaItem.Builder().setUri(m).setClippingConfiguration(clip(0L, outDurMs)).build()
            ).build()
            sequences.add(EditedMediaItemSequence(listOf(musicItem)))
        }

        val composition = Composition.Builder(sequences).build()
        val outFile = File(cacheDir, "export_${System.currentTimeMillis()}.mp4")

        val t = Transformer.Builder(this)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    onExportDone(outFile)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    exporting = false
                    b.progress.visibility = View.GONE
                    b.btnExport.isEnabled = true
                    b.tvStatus.text = "Export fail: ${exportException.message}"
                }
            })
            .build()
        transformer = t

        exporting = true
        b.btnExport.isEnabled = false
        b.progress.progress = 0
        b.progress.visibility = View.VISIBLE
        b.tvStatus.text = "Export ho raha hai..."
        player?.pause()

        t.start(composition, outFile.absolutePath)
        pollProgress()
    }

    private fun pollProgress() {
        val t = transformer ?: return
        if (!exporting) return
        val holder = ProgressHolder()
        val state = t.getProgress(holder)
        if (state != Transformer.PROGRESS_STATE_NOT_STARTED) {
            b.progress.progress = holder.progress
        }
        handler.postDelayed({ pollProgress() }, 400)
    }

    private fun onExportDone(file: File) {
        Thread {
            val saved = saveToGallery(file)
            file.delete()
            runOnUiThread {
                exporting = false
                b.progress.visibility = View.GONE
                b.btnExport.isEnabled = true
                b.tvStatus.text =
                    if (saved != null) "Ho gaya! Gallery > Movies > ClipForge mein hai"
                    else "Video bani par save nahi ho payi"
            }
        }.start()
    }

    private fun saveToGallery(file: File): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "ClipForge_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ClipForge")
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: return null
        contentResolver.openOutputStream(uri)?.use { out ->
            file.inputStream().use { it.copyTo(out) }
        }
        return uri
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        exporting = false
        handler.removeCallbacksAndMessages(null)
        transformer?.cancel()
        player?.release()
        player = null
        super.onDestroy()
    }
}
