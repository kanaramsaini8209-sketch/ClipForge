# ClipForge - simple video editor (Kotlin + Media3)

## Features (Phase 1)
- Video import, trim (range slider)
- Filters: B&W, Invert, Vintage, Warm, Cool, Vivid, Fade
- Brightness, contrast, saturation
- Speed 0.25x - 4x
- Text overlay (position + size)
- Music add + original awaaz mute
- Export 720p / 1080p / original -> Gallery > Movies > ClipForge

## APK banane ka tareeka (sirf phone se)
1. github.com par free account banao, naya repository banao (e.g. `ClipForge`).
2. Is zip ke andar ki saari files repo mein upload karo (`.github` folder samet).
3. Repo ke **Actions** tab mein **Build APK** chalne do (5-8 min).
4. Run complete hone par neeche **Artifacts > ClipForge-APK** download karo.
5. Zip se `app-debug.apk` nikaalo aur install karo.

## Android Studio se
Folder open karo aur Run dabao. (minSdk 29 = Android 10+)

## Abhi nahi hai
Multi-clip timeline, split, transitions, stickers, auto captions, background remove.
